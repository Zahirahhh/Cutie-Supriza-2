<!DOCTYPE html>
<html>
<head>
     <meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel = "icon" type = "png" href = "admin1.png">
	<title>Bye Bye</title>
<style>
body{
     background-image:url("try.png");
	 text-align:center;
	 background-repeat: no-repeat;
	 font-family:pencil sharp;
	 font-weight: bold;
     font-size:100px;
	 height:720px;
	 width:1280px;
	 
	
}

</style>
</head>
<body>

<br>
THANK YOU FOR UPDATING YOUR ACCOUNT....<br>
......HAVE A NICE DAY.....
</body>
</html>